Interspire Design Templates

Please read copyright information in copyright.txt before proceeding with installation.

Download File Usage and Installation
-----------------------------------------------------

For a Website/Email template package

Step 1. Unzip the package into a folder on your local drive.

Step 2. Upload the folder to your website and then access using your domain name.


For a logo template package

Step 1. Unzip the package into a folder on your local drive.

Step 2. Open the design in either Illustrator or Photoshop format to allow you to change the 'Company Name'

Step 3. Export the graphic to insert it into other publications.


For more information regarding our free and other Interspire products, visit:
http://www.interspire.com

