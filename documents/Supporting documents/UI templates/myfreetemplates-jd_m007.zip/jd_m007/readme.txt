# myfreetemplates.com
# 
# Copyright � 2001-2003 MyFreeTemplates.com - All Rights Reserved
# THIS COPYRIGHT INFORMATION MUST REMAIN INTACT
# AND MAY NOT BE MODIFIED IN ANY WAY
#
# When you downloaded the package you agreed to accept the terms
# of this Agreement. This Agreement is a legal contract, which
# specifies the terms of the license and warranty limitation between
# you and 'myfreetemplates.com'. You should carefully read the following
# terms and conditions before using the package.
# 
# If you do not agree to the terms of this Agreement, promptly delete
# and destroy all copies of the Software.
#
# License to Redistribute
# Distributing the software, design and/or documentation with other products
# (commercial or otherwise) by any means without prior written 
# permission from 'myfreetemplates.com' is forbidden.
# All rights to the downloaded design and documentation not expressly
# granted under this Agreement are reserved to 'myfreetemplates.com'.
#
# Disclaimer of Warranty
# THIS SOFTWARE, DESIGN AND ACCOMPANYING DOCUMENTATION ARE PROVIDED "AS IS" 
# AND WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY 
# OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED.   BECAUSE OF THE 
# VARIOUS HARDWARE AND SOFTWARE ENVIRONMENTS INTO WHICH THE PACKAGE 
# MAY BE USED, NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE IS 
# OFFERED.  THE USER MUST ASSUME THE ENTIRE RISK OF USING THIS PACKAGE
# 
# IN NO CASE SHALL 'myfreetemplates.com' BE LIABLE FOR ANY INCIDENTAL, SPECIAL OR
# CONSEQUENTIAL DAMAGES OR LOSS, INCLUDING, WITHOUT LIMITATION,
# LOST PROFITS OR THE INABILITY TO USE EQUIPMENT
# OR ACCESS DATA, WHETHER SUCH DAMAGES ARE BASED UPON A BREACH OF 
# EXPRESS OR IMPLIED WARRANTIES, BREACH OF CONTRACT, NEGLIGENCE, 
# STRICT TORT, OR ANY OTHER LEGAL THEORY.
# THIS IS TRUE EVEN IF 'myfreetemplates.com' IS ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGES.

# Warning: This package is protected by copyright law. Unauthorized 
# reproduction or distribution of this program, or any portion of it,
# may result in severe civil and criminal penalties, and will be
# prosecuted to the maximum extent possible under the law.
#
# Credits:
# 
# Site Director: Eddie Machaalani
# Creative Director: Joseph De Araujo
# Marketing Manager: Sue Chandrasekera
# 
#
# For more information about this freely accessible design package and other 
# freely accessible design packages please see
# http://www.myfreetemplates.com
#
# Thank you for downloading our product.
# If you have any suggestions or ideas please direct them to 
# info@myfreetemplates.com
#
# We welcome all feedback and questions for support on our new online forum
# http://www.interspire.com/forum
#
# MyFreeTemplates.com is an Interspire Product (www.interspire.com)




