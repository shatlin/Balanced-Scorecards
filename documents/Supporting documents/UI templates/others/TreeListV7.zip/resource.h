//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TreeList.rc
//
#define IDC_EDIT                        2
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TREELIST_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDB_FALGS                       129
#define IDC_CHECK1                      1000
#define IDC_CHECK2                      1001
#define IDC_CHECK3                      1002
#define IDC_CHECK4                      1003
#define IDC_CHECK5                      1004
#define IDC_CHECK6                      1005
#define IDC_CHECK7                      1006
#define IDC_CHECK8                      1007
#define IDC_CHECK9                      1008
#define IDC_CHECK10                     1009
#define IDC_CHECK11                     1010
#define IDC_CHECK12                     1011
#define IDC_FRAME                       1012
#define IDC_CHECK13                     1013
#define IDC_CHECK14                     1014
#define IDC_CHECK15                     1015
#define IDC_CHECK16                     1016
#define IDC_CHECK17                     1017
#define IDC_CHECK18                     1018
#define IDC_COMBO1                      1019
#define IDC_COMBO2                      1020
#define IDC_COMBO3                      1021
#define IDC_COMBO4                      1022
#define IDC_COMBO5                      1023
#define IDC_COMBO6                      1024
#define IDC_COMBO7                      1025
#define IDC_COMBO8                      1026
#define IDC_CHECK19                     1027
#define IDC_CHECK20                     1028
#define IDC_CHECK21                     1029
#define IDC_EDIT1                       1030
#define IDC_EDIT2                       1031
#define IDC_EDIT4                       1035
#define IDC_COMBO                       1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
